create database  assignment_2_E1
use assignment_2_E1

--PUBLISHER (PublisherID#, PublisherName)
create table PUBLISHER
(
  PublisherID int primary key,
  PublisherName nvarchar(30)
)
--AUTHOR (AuthorID#, AuthorFirstName, AuthorLastName)
create table AUTHOR 
(
AuthorID int primary key,
AuthorFirstName nvarchar(15),
AuthorLastName nvarchar(15)
)
--CATEGORY (CategoryID#, CategoryDescription)

create table CATEGORY
(
CategoryID int primary key,
CategoryDescription nvarchar(50)
)
--BOOK_FORMAT (BookFormat#, FormatDescription)
create table BOOK_FORMAT
(
BookFormat nvarchar(5) primary key,
FormatDescription nvarchar(50)
)




--BOOK_TITLE (ISBN_Number#, Title, PublisherID, PublishedDate, BookFormat, Pages, Price)
create table BOOK_TITLE(
ISBN_Number int primary key,
Title nvarchar(10),
PublisherID int,
PublishedDate datetime,
BookFormat nvarchar(5),
Pages int,
Price int ,
constraint fk1 foreign key (PublisherID) references PUBLISHER(PublisherID)  on update cascade on delete cascade,
constraint fk2 foreign key (BookFormat) references BOOK_FORMAT(BookFormat)  on update cascade on delete cascade
)
--BOOK_AUTHOR (ISBN_Number#, AuthorID#)
create table BOOK_AUTHOR(
 ISBN_Number int ,
 AuthorID int,
 constraint fk3 foreign key (ISBN_Number) references BOOK_TITLE(ISBN_Number)  on update cascade on delete cascade,
 constraint fk4 foreign key (AuthorID) references AUTHOR(AuthorID)  on update cascade on delete cascade
)
--BOOK_CATEGORY (ISBN_Number#, CategoryID#)
create table BOOK_CATEGORY
(
ISBN_Number int ,
CategoryID int ,
constraint fk5 foreign key (ISBN_Number) references BOOK_TITLE(ISBN_Number)  on update cascade on delete cascade,
constraint fk6 foreign key (CategoryID) references CATEGORY(CategoryID)  on update cascade on delete cascade
)
 












