create database assignment_E2
use assignment_E2
 create table student (
 ssn int primary key,
 sname  nvarchar(30),
 major nvarchar(30),
 bdate datetime
 )
 
 --COURSE (Course#, Cname, Dept)
 create table courses (
 course int primary key,
 cname nvarchar(30),
 dept datetime
 )
 --ENROLL (SSN#, Course#, Quarter, Grade)
 
create table enroll (
 ssn int ,
 course int ,
 quarters nvarchar(10),
 grade nvarchar(10),
 constraint fk1 foreign key (ssn) references student(ssn)  on update cascade on delete cascade,
 constraint fk2 foreign key (course) references courses(course)  on update cascade on delete cascade
)
--BOOK_ADOPTION (Course#, Quarter, Book_ISBN#)
create table book_adoption(
course int,
quarters nvarchar(10),
book_isbn int primary key,
constraint fk3 foreign key (course) references courses(course)  on update cascade on delete cascade,

)

--TEXT (Book_ISBN#, Book_Title, Publisher, Author)

create table texts
(
book_isbn int ,
book_title nvarchar(30),
Publisher nvarchar(30),
author nvarchar(30),
constraint fk4 foreign key (book_isbn) references book_adoption(book_isbn)  on update cascade on delete cascade

)
