create database assignment_E1
 use assignment_E1
 create table employees(
 ssn char(5) primary key,
 salary int,
 phone char(10),
 dno char(5),
 constraint FK1 foreign key (dno) references departments(dno) on update cascade on delete cascade
 )
 create table departments(
 dno char(5) primary key,
 dname nvarchar(30),
 budget nvarchar(30)
 )
 create table children (
 name nvarchar(30),
 age int ,
 ssn char(5)
 constraint FK2 foreign key (ssn) references employees(ssn) on update cascade on delete cascade
 )
